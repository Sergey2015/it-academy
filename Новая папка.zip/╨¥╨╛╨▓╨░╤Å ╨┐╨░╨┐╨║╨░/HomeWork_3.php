<?php
$aaa=1;
phpinfo();
echo "string";
echo "$aaa";